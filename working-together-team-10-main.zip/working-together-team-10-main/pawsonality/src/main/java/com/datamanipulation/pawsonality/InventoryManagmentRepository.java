package com.datamanipulation.pawsonality;

import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryManagmentRepository extends JpaRepository<InventoryManagmentProducts, Long>{
}
